package com.example.petadopt

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class ConfirmaciónActivity: AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.confirmacion)

        // Acceder a la actividad de Inicio
        val buttonIrAInicio: Button = findViewById(R.id.button6)

        // Establecer el clic del botón para ir a la actividad Inicio
        buttonIrAInicio.setOnClickListener {
            val intentInicio = Intent(this@ConfirmaciónActivity, MainActivity::class.java)
            startActivity(intentInicio)
        }
    }
}
