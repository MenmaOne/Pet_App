package com.example.petadopt

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class CitaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.cita)
        // Acceder a la actividad de confirmación
        val buttonIrAConfirmacion: Button = findViewById(R.id.button5)

        // Establecer el clic del botón para ir a la actividad Confirmacion
        buttonIrAConfirmacion.setOnClickListener {
            val intentConfirmacion = Intent(this@CitaActivity, ConfirmaciónActivity::class.java)
            startActivity(intentConfirmacion)
        }
    }
}




