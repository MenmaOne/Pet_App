package com.example.petadopt

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class DetallePerroActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.detalle_perro)

        // Acceder a la actividad de citas
        val buttonIrACitaPerro: Button = findViewById(R.id.button2)

        // Establecer el clic del botón para ir a la actividad CitaActivity
        buttonIrACitaPerro.setOnClickListener {
            val intentCitaPerro = Intent(this@DetallePerroActivity, CitaActivity::class.java)
            startActivity(intentCitaPerro)
        }
    }
}
