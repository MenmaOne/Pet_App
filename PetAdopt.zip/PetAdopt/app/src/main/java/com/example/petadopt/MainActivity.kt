package com.example.petadopt

import android.content.Intent
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Botón para ir a la pantalla de detalles del perro
        val buttonDetallePerro: Button = findViewById(R.id.button3)
        buttonDetallePerro.setOnClickListener {
            val intentPerro = Intent(this@MainActivity, DetallePerroActivity::class.java)
            startActivity(intentPerro)
        }

        // Botón para ir a la pantalla de detalles del gato
        val buttonDetalleGato: Button = findViewById(R.id.button)
        buttonDetalleGato.setOnClickListener {
            val intentGato = Intent(this@MainActivity, DetalleGatoActivity::class.java)
            startActivity(intentGato)
        }

        // Inflar la vista de detalle.xml
        val detalleView = layoutInflater.inflate(R.layout.detalle, null)

        // Buscar el botón en la vista inflada de detalle.xml
        val buttonDetalle: Button = detalleView.findViewById(R.id.button4)

    }
}
