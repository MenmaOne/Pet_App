package com.example.petadopt

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class DetalleGatoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.detalle)

        // Acceder a la actividad de citas
        val buttonIrACita: Button = findViewById(R.id.button4)

        // Establecer el clic del botón para ir a la actividad CitaActivity
        buttonIrACita.setOnClickListener {
            val intentCita = Intent(this@DetalleGatoActivity, CitaActivity::class.java)
            startActivity(intentCita)
        }
    }
}
